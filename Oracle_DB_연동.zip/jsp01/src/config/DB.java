package config;

import java.sql.Connection;
import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.Context;

public class DB {
	public static Connection dbConn() {
		DataSource ds = null;
		Connection conn = null;
		try {
			// context.xml ������ �м��ϴ� Ŭ����
			Context ctx = new InitialContext();
			ds = (DataSource)ctx.lookup("java:comp/env/oraDB");
			conn=ds.getConnection();
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		return conn;
	}
}
